
<?php $__env->startSection('konten'); ?>
<h4>Edit Barang</h4>
    <form action="<?php echo e(route('barang.update', $barang->idBarang)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <!-- <label>ID Barang:</label>
        <input type="text" name="namaBarang" value="<?php echo e($barang->idBarang); ?>" id="idBarang" class="form-control mb-2"> -->
        <label>Nama Barang:</label>
        <input type="text" name="namaBarang" value="<?php echo e($barang->namaBarang); ?>" id="namaBarang" class="form-control mb-2">
        <label>Merk:</label>
        <input type="text" name="merk" value="<?php echo e($barang->merk); ?>" id="merk" class="form-control mb-2">
        <label>Harga Jual:</label>
        <input type="text" name="hargaJual" value="<?php echo e($barang->hargaJual); ?>" id="hargaJual" class="form-control mb-2">
        <label>Stock:</label>
        <input type="text" name="stok" value="<?php echo e($barang->stok); ?>" id="stok" class="form-control mb-2">
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutBarang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/barang/edit.blade.php ENDPATH**/ ?>