
<?php $__env->startSection('konten'); ?>
<h4>Penambahan Barang</h4>
    <form action="<?php echo e(route('barang.submitBarang')); ?>" method="POST">
    <?php echo csrf_field(); ?>
        <label>ID Barang:</label>
        <input type="text" name="idBarang" id="idBarang" class="form-control mb-2">
        <label>Nama Barang:</label>
        <input type="text" name="namaBarang" id="namaBarang" class="form-control mb-2">
        <label>Merk:</label>
        <input type="text" name="merk" id="merk" class="form-control mb-2">
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutBarang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/barang/add.blade.php ENDPATH**/ ?>