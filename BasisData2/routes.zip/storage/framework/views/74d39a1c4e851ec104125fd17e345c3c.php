<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Pembayaran & Items yang dibeli</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="<?php echo e(url('css/main.css')); ?>">
    <script src='main.js'></script>
</head>
<body>
    <h1 class="text-center">Pembayaran & Items yang diBeli</h1>   
    <nav class="navbar navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
        <div class="container-fluid">
             <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                  <div class="navbar-nav">

                </div>
            </div>
        </div>
    </nav>
    <div class="mt-3 container">
    <h4>List Data Barang</h4>
    <table class="table">
        <tr>
            <th>ID Transaksi</th>
            <th>ID Barang</th>
            <th>Jumlah</th>
            <th>Harga Total</th>
        </tr>
        <?php $__currentLoopData = $detailTransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->idTransaksi); ?></td>
            <td><?php echo e($data->idBarang); ?></td>
            <td><?php echo e($data->jumlahBarang); ?></td>
            <td><?php echo e($data->totalHarga); ?></td>
        </tr>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>Total Harga :</td>
            <td></td>
            <td></td>
            <td><?php echo e($totalharga); ?></td>
        </tr>
    </table>
    <div class="d-flex">
        <h4>Pembayaran</h4>
        <div class="ms-auto">
        <a class="btn btn-success" href="<?php echo e(route('lunas')); ?>" >Lunas</a>
            <a class="btn btn-danger" href="<?php echo e(route('ngutang')); ?> ">Ngutang</a>
        </div>
    </div>  
    </div>
    

</body>
</html><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/viewTransaksi.blade.php ENDPATH**/ ?>