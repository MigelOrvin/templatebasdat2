
<?php $__env->startSection('konten'); ?>
    <h4>Penambahan Mobil</h4>
        <form action="<?php echo e(route('mobil.submitMobil')); ?>" method="POST">
        <?php echo csrf_field(); ?>
            <label>Plat Kendaraan:</label>
            <input type="text" name="platKendaraan" id="platKendaraan" class="form-control mb-2">
            <label>jenis:</label>
            <input type="text" name="jenis" id="jenis" class="form-control mb-2">
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutMobil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/mobil/add.blade.php ENDPATH**/ ?>