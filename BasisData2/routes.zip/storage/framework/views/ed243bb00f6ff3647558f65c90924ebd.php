
<?php $__env->startSection('konten'); ?>
<?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
<div class="d-flex">
        <h4>List Data Mobil</h4>
        <div class="ms-auto">
        <a class="btn btn-success" href="<?php echo e(route('mobil.add')); ?>">Tambah Mobil</a>
        </div>
    </div>
    <table class="table">
    <table class="table">
        <tr>
            <th>Plat Kendaraan</th>
            <th>Jenis</th>
            <th>Status Mobil</th>
        </tr>
        <?php $__currentLoopData = $mobil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->platKendaraan); ?></td>
            <td><?php echo e($data->jenis); ?></td>
            <td><?php echo e($data->statusMobil); ?></td>
            <td>
            <form action="<?php echo e(route('mobil.delete', $data->platKendaraan)); ?>" method="POST" onsubmit="return confirm('Apakah Anda Yakin Menghapus ini? Data yang berkaitan dengan kendaraan ini akan hilang')" >
                    <?php echo csrf_field(); ?>
                    <button id="delete" class="btn btn-sm btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutMobil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/mobil/view.blade.php ENDPATH**/ ?>