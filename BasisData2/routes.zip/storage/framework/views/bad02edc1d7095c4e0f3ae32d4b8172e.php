
<?php $__env->startSection('konten'); ?>
    
<div class="d-flex">
        <h4>Informasi Stok yang sedikit</h4>
    </div>
    <table class="table">
        <tr>
            <th>ID Barang</th>
            <th>Nama Barang</th>
            <th>Stok</th>
        </tr>
        <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->idBarang); ?></td>
            <td><?php echo e($data->namaBarang); ?></td>
            <td><?php echo e($data->stok); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutBarang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/barang/info.blade.php ENDPATH**/ ?>