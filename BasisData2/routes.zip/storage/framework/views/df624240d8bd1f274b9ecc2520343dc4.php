
<?php $__env->startSection('konten'); ?>
    <h4>Edit Karyawan</h4>
    <form action="<?php echo e(route('karyawan.update', $karyawan->nik)); ?>" method="POST">
    <?php echo csrf_field(); ?>
        <label>Nama:</label>
        <input type="text" name="nama" value="<?php echo e($karyawan->nama); ?>" id="nama" class="form-control mb-2">
        <label>Nomor Telepon:</label>
        <input type="text" name="noTelp" value="<?php echo e($karyawan->noTelp); ?>" id="noTelp" class="form-control mb-2">
        <label>Alamat:</label>
        <input type="text" name="alamat" value="<?php echo e($karyawan->alamat); ?>" id="alamat" class="form-control mb-2">
        
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutKaryawan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/karyawan/edit.blade.php ENDPATH**/ ?>