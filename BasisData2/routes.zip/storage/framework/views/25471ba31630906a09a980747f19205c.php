
<?php $__env->startSection('konten'); ?>
    
<div class="d-flex">
        <h4>Informasi Pengiriman</h4>
    </div>
    <table class="table">
        <tr>
            <th>ID Pengiriman</th>
            <th>Tanggal Pengiriman</th>
            <th>Status Pengiriman</th>
            <th>Tanggal Transaksi</th>
            <th>Plat Kendaraan</th>
            <th>Nama Karyawan</th>

        </tr>
        <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->idPengiriman); ?></td>
            <td><?php echo e($data->tanggalPengiriman); ?></td>
            <td><?php echo e($data->statusPengiriman); ?></td>
            <td><?php echo e($data->tanggalTransaksi); ?></td>
            <td><?php echo e($data->platKendaraan); ?></td>
            <td><?php echo e($data->namaKaryawan); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/view/informasiPengiriman.blade.php ENDPATH**/ ?>