
<?php $__env->startSection('konten'); ?>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <div class="d-flex">
        <h4>List Data Karyawan</h4>
        <div class="ms-auto">
        <a class="btn btn-success" href="<?php echo e(route('karyawan.add')); ?>">Tambah Karyawan</a>
        </div>
    </div>
    <table class="table">
        <tr>
            <th>NIK</th>
            <th>Nama</th>
            <th>No Telp</th>
            <th>Alamat</th>
            <th>Jenis Kelamin</th>
            <th>Gaji Minggu ini</th>
            <th>Tanggal Masuk</th>
            <th>Bon</th>
            <th>Gaji Bersih</th>
        </tr>
        <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->nik); ?></td>
            <td><?php echo e($data->nama); ?></td>
            <td><?php echo e($data->noTelp); ?></td>
            <td><?php echo e($data->alamat); ?></td>
            <td><?php echo e($data->jenisKelamin); ?></td>
            <td><?php echo e($data->gaji); ?></td>
            <td><?php echo e($data->tanggalMasuk); ?></td>
            <td><?php echo e($data->Bon); ?></td>
            <td><?php echo e($data->gaji - $data->Bon); ?></td>
            <td>
            <a href="<?php echo e(route('karyawan.edit', $data->nik)); ?>" class="btn btn-sm btn-warning">Edit</a>
                <form action="<?php echo e(route('karyawan.delete', $data->nik)); ?>" method="POST" onsubmit="return confirm('Apakah Anda Yakin Menghapus ini?')" >
                    <?php echo csrf_field(); ?>
                    <button id="delete" class="btn btn-sm btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="d-flex">
        <h4>Edit Section</h4>
        <div class="ms-auto">
        <a class="btn btn-success" href="<?php echo e(route('karyawan.gaji')); ?>">Tambah Gaji Karyawan</a>
            <a class="btn btn-danger" href="<?php echo e(route('karyawan.bon')); ?>">Tambah Bon Karyawan</a>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutKaryawan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/karyawan/view.blade.php ENDPATH**/ ?>