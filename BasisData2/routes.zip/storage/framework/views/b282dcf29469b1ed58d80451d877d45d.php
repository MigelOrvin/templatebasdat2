
<?php $__env->startSection('konten'); ?>
    <h4>Penambahan Supplier</h4>
    <form action="<?php echo e(route('supplier.update', $supplier->idSupplier)); ?>" method="POST">
    <?php echo csrf_field(); ?>
        <label>Nomor Telepon:</label>
        <input type="text" name="noTelp" value="<?php echo e($supplier->noTelp); ?>" id="noTelp" class="form-control mb-2">
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutSupplier', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/supplier/edit.blade.php ENDPATH**/ ?>