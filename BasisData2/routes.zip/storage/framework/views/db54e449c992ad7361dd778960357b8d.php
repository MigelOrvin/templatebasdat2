
<?php $__env->startSection('konten'); ?>
    
<div class="d-flex">
        <h4>Informasi Barang Yang Terjual</h4>
    </div>
    <table class="table">
        <tr>
            <th>Nama Barang</th>
            <th>Total Jumlah Barang Terjual</th>
            <th>Total Pendapatan</th>
        </tr>
        <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->namaProduk); ?></td>
            <td><?php echo e($data->totalJumlahBarangTerjual); ?></td>
            <td><?php echo e($data->totalPendapatan); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/view/history.blade.php ENDPATH**/ ?>