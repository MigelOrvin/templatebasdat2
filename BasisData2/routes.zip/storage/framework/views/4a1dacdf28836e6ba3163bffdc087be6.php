
<?php $__env->startSection('konten'); ?>
<?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <div class="d-flex">
        <h4>List Data Barang</h4>
        <div class="ms-auto">
        <a class="btn btn-success" href="<?php echo e(route('barang.add')); ?>">Tambah Barang</a>
        <a class="btn btn-warning" href="<?php echo e(route('barang.info')); ?>">Low Stok Items</a>
        </div>
    </div>
    <table class="table">
        <tr>
            <th>ID Barang</th>
            <th>Nama Barang</th>
            <th>Merek</th>
            <th>Harga Jual</th>
            <th>Stock</th>
            <th>Aksi</th>
        </tr>
        <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->idBarang); ?></td>
            <td><?php echo e($data->namaBarang); ?></td>
            <td><?php echo e($data->merk); ?></td>
            <td><?php echo e($data->hargaJual); ?></td>
            <td><?php echo e($data->stok); ?></td>
            <td><a href="<?php echo e(route('barang.edit', $data->idBarang)); ?>" class="btn btn-sm btn-warning">Edit</a>
            <form action="<?php echo e(route('barang.delete', $data->idBarang)); ?>" method="POST" onsubmit="return confirm('Apakah Anda Yakin Menghapus ini?')" >
                    <?php echo csrf_field(); ?>
                    <button id="delete" class="btn btn-sm btn-danger">Delete</button>
                </form>    
        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutBarang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BasisData2\resources\views/barang/view.blade.php ENDPATH**/ ?>