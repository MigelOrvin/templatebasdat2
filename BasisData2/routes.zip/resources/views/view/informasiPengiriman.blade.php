@extends('layoutView')
@section('konten')
    
<div class="d-flex">
        <h4>Informasi Pengiriman</h4>
    </div>
    <table class="table">
        <tr>
            <th>ID Pengiriman</th>
            <th>Tanggal Pengiriman</th>
            <th>Status Pengiriman</th>
            <th>Tanggal Transaksi</th>
            <th>Plat Kendaraan</th>
            <th>Nama Karyawan</th>

        </tr>
        @foreach ($info as $no=>$data)
        <tr>
            <td>{{ $data->idPengiriman}}</td>
            <td>{{ $data->tanggalPengiriman }}</td>
            <td>{{ $data->statusPengiriman }}</td>
            <td>{{ $data->tanggalTransaksi}}</td>
            <td>{{ $data->platKendaraan}}</td>
            <td>{{ $data->namaKaryawan}}</td>
        </tr>
        @endforeach
    </table>
@endsection